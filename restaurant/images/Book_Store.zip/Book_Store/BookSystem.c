#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

// #include "func.h"

#define SIZE 50


	// this struct is given 
typedef struct book{
	char* title;
	char* release_date;
	float price;
}book;

typedef struct author{
	int writer_id;
	char* surname;
	char* name;
	int num_of_books;
}author;

typedef struct writes{
	
	int writer_id;
	char* title;
	
}writes;


	// this one I created it 
typedef struct gen {
    book *book_arr;
    author *author_arr;
    writes *writes_arr;
    int capacity;
    int size;
}gen;


int menu();
void add_book(gen *bk);
void add_author(gen *aut,int total); 
void MemForBooks(gen *bk, int cap);
void MemForAuthors(gen *aut,int cap);
int search_authors(gen *aut, char *name);
void order_authors(author *aut1, author *aut2);
void do_sort_authors(gen *aut, int cap);
int do_print_authors(gen *aut, char *name);
int delete_authors(gen *aut, char* name);
void save_authors_to_file(gen *aut,char *Authors);
void save_books_to_file(gen *bk,char *gen);
	


int main(int argc, char** argv){
	
	int choice = menu();
	
	int total=0; 
	
	int pos; // for position !
	
	char title[SIZE], name[SIZE];
	gen bk; 

	MemForAuthots(&bk,10);
	MemForBooks(&bk, 10);
	 
	while(choice){
		
		
		if(choice==1){
			add_author(&bk);
		}else if (choice==2){
			add_book(&bk);			
		}else if ( choice==3 ){
			
			printf("Give the name of the writer you want to search: ");
			scanf("%s",&name);
			pos = search_author(&bk, name);
			if(pos!=-1){
				printf("Author %d is found in the position: %d \n", name, pos);
				do_print_authors(&bk, bk.author_arr[pos].name );
			}else{
				printf("We did not found this writer");
			}
			
		}else if (choice==4){
			
			printf("Give the title of the book you want to search for: ");
			scanf("%s",&title);
			if(pos!=-1){
				printf("The %d is found in the position: %d \n", title, pos);
				do_print_books(&bk,bk.book_arr[pos].title);
			}else{
				printf("We did not found this book in our archive \n ");
			}
			
		}else if(choice==5){
			
			printf("Who is the author you want to delete? \n ");
			scanf("%s",&name);
			
			if(!delete_authors(&bk,title)){
				printf("We didn't found  the book you want to delete \n");
			}else {
				printf("the %s has been deleted", title);
			}
			
		}else if(choice==6){
			
			printf("What is the book you want to delete? \n ");
			scanf("%s", &title);
			
			if(!delete_books(&bk,title)){
				printf("We didn't found  the book you want to delete \n");
			}
		}else{
			break; 	
		}
		
		choice = menu();
	
	}
	
	return 0;	
}



 	// The menu that the user can see 
int menu (){
	
	int choice;
	 
	printf("1. Insert new writer record");
	printf("2. Insert new book record");
	printf("3. Search a writer record");
	printf("4. Search a book record"); 
	printf("5. Delete a writer record"); 
	printf("6. Delete a book record"); 
	printf("7. Exit");
	
	scanf("%d",&choice);
	
	if(choice<1 && choice>7){
		printf("Wronge choice of number");
	}
	
	return choice; 	
	
}


	// Intialize Dynamic Memory for the author  struct 
void MemForAuthors(gen *aut,int cap){
	
	aut->author_arr=(author*)malloc(sizeof(book)* cap);
	aut->capacity= cap ; 
	aut->size = 0 ; 
	
}


void add_author(gen *aut, int *total){

	author a;
	
	author[*total].writer_id = author[*total -1 ].writer_id + 1 ; 
	author[*total].num_of_books = author[*total -1 ].num_of_books + 1 ; 

	
	printf("Give his surname of the author: ");
    scanf("%s", &a.surname);
    printf("Give the name of the author: ");
    scanf("%s", &a.name);	
   
    if (aut->size >= aut->capacity) {
        aut->capacity += 10;
        aut->book_arr = realloc(aut->author_arr, sizeof(author) * aut->capacity);
    }
   	
	strcpy(aut->author_arr[aut->size].surname, a.surname);			// strcpy cuz this is string
	strcpy(aut->author_arr[aut->size].name, a.name);  				// strcpy cuz this is string 
   	
    aut->size++;
}


	// Here we are searching for the i that the user gave!
int search_authors(gen *aut, char *name){
	
	int i ; 
	
	for(i=0; i<aut->size; i++){
		if(name == aut->author_arr[i].name){
			return i ;
		}
	}

	return -1;
}	

void order_authors(author *aut1, author *aut2){
	
	author tmp;

    tmp = *aut1;
    *aut1 = *aut2;
    *aut2 = tmp;
}


	// sort  through the stdlib  includes qsort
void do_sort_authors(gen *aut, int cap) {
	
	qsort(aut, cap, sizeof(aut), order_authors);
	
}



int do_print_authors(gen *aut, char *name){
	
	int i ;
	int pos;
	
	do_sort_authors(name,cap);
	
	pos = search_authors(aut, name);
	
	if(pos == -1 ){
		printf("no author \n");
	}
		
	for(i=0 ; i<size; i ++){
		
		if(strcmp(name , aut->author_arr[i].name)==0){
			
			printf("ID %d \n", aut->author_arr[pos].writer_id);
			printf("Name %s \n", aut->author_arr[pos].name);
			printf("Surname %s \n", aut->author_arr[pos].surname);
			printf("Num_of_Books: %d \n", aut->author_arr[pos].num_of_books);
			
		}
		
	}
	
	return 1;
}

// Here  delete the Book fromy  array that we created . 
int delete_authors(gen *aut, char* name){
	
    int pos;

	// he trying to see if the title that we gave  all ready exists . 
    if((pos=search_authors(aut, title)) == -1) {
        return 0;
    }

	//tell the book to reOrder the array.. through pointers technique 
    do_sort_authors(&aut->author_arr[pos], &aut->author_arr[aut->size-1]);
    aut->size--;

    return 1;
}


void save_authors_to_file(gen *aut,char *Authors){
	
	int i;
	FILE *fp;
	
	if((fp=fopen("Authors.txt","w"))== NULL){
		fprintf(stderr, "Error.\n");
		return; 
	}
	
	for(i=0; i<aut->size;i ++){
		fprintf(fp,"%d", aut->author_arr[i].writer_id);
		fprintf(fp,"%s", aut->author_arr[i].surname);
		fprintf(fp,"%s", aut->author_arr[i].name);
		fprintf(fp,"%d", aut->author_arr[i].num_of_books);
	}
}



	// Intialize Dynamic Memory for the books  struct 
void MemForBooks(gen *bk, int cap){
	bk->book_arr = (book*)malloc(sizeof(book) * cap);
    bk->capacity = cap;
    bk->size = 0;
}


	// I'm trying to insert the books into the array ....
void add_book(gen *bk){
	
	book b;

    printf("Give a title: ");
    scanf("%s", &b.title);
    printf("Give the release date: ");
    scanf("%d", &b.release_date);
    printf("The price of the book:  ");
    scanf("%d", &b.price);
    
    if (gen->size >= gen->capacity) {
        gen->capacity += 10;
        gen->book_arr = realloc(gen->book_arr, sizeof(book) * gen->capacity);
    }
    
   	strcpy(gen->book_arr[gen->size].title, b.title); // strcpy cuz this is string 
    gen->book_arr[gen->size].release_date = b.release_date;
	gen->book_arr[gen->size].price = b.price;

    gen->size++;
}


	// Here we are searching for the i that the user gave!
int search_books(gen *bk, char *title){

	int i ; 

	for(i=0; i<bk->size; i++){
		if(title == bk->book_arr[i].title){
			return i ;
		}
	}

	return -1;

}

	// order the Books array through pointers technique .
void order_books(book *b1, book *b2){
	
    book tmp;

    tmp = *b1;
    *b1 = *b2;
    *b2 = tmp;
}

	// sort  through the stdlib  includes qsort
void do_sort_books(gen *bk, int cap) {
	
	qsort(bk, cap, sizeof(bk), order_books);
	
}

int do_print_books(gen *bk, char *title){
	
	int i ;
	int pos;
	
	do_sort_books(title,cap);
	
	pos = search_books(bk, title);
	
	if(pos == -1 ){
		printf("there is no such a book  \n");
	}
		
	for(i=0 ; i<size; i ++){
		
		if(strcmp(title , bk->book_arr[i].title)==0){
			
			printf("price of the book: %d \n", bk->book_arr[pos].price);
			printf("The title of the booked you searched: %s \n", bk->book_arr[pos].title);
			printf("The release date of the book is: %s \n", bk->book_arr[pos].release_date);
		
		}
		
	}
	
}

	// Here  delete the Book fromy  array that we created . 
int delete_books(gen *bk, char* title){
	
    int pos;

	// he trying to see if the title that we gave  all ready exists . 
    if((pos=search_book(bk, title)) == -1) {
        return 0;
    }

	//tell the book to reOrder the array.. through pointers technique 
    Order_books(&bk->book_arr[pos], &bk->book_arr[bk->size-1]);
    bk->size--;

    return 1;
}




	//Here with fprintf we are printing the users input onto the file.  
void save_books_to_file(gen *bk,char *Books){
    int i;
    FILE *fp;

    if ((fp = fopen("Books.txt", "w")) == NULL ){
        fprintf(stderr, "Error.\n");
        return; 
    }
    
    for (i=0; i<bk->size; i++) {
        fprintf(fp, "%s ", bk->book_arr[i].title);
        fprintf(fp, "%d ", bk->book_arr[i].release_date);
        fprintf(fp, "%d ", bk->book_arr[i].price);
    }

    fclose(fp);
}






