import time

def heapify(data, drawdata, speed, n, i):
	largest = i # Initialize largest as root
	l = 2 * i + 1 # left = 2*i + 1
	r = 2 * i + 2 # right = 2*i + 2

	if l < n and data[i] < data[l]:
		largest = l
		drawdata(data, getColorArray(len(data), i, l))

	if r < n and data[largest] < data[r]:
		largest = r
		drawdata(data, getColorArray(len(data), i, l))

	if largest != i:
		drawdata(data, getColorArray(len(data), i, l))
		(data[i], data[largest]) = (data[largest], data[i]) # swap

    # time.sleep(speed)
	heapify(data,drawdata,speed, n, largest)



def getColorArray(dataLen, i, j):
	colorArray = []
	for x in range(dataLen):
		if x == i or x == j:
			colorArray.append('red')
		else:
			colorArray.append('black')
	return colorArray

# The main function to sort an array of given size

def heapSort(data, drawdata, speed):
	n = len(data)

# Build a maxheap.
# Since last parent will be at ((n//2)-1) we can start at that location.

	for i in range(n // 2 - 1, -1, -1):
		heapify(data,drawdata,speed, n, i)

# One by one extract elements

	for i in range(n - 1, 0, -1):
		(data[i], data[0]) = (data[0], data[i]) # swap
		heapify(data, i, 0)

	drawdata(data, ['green' for x in range(len(data))])